# Files Readme coming soon

The File below will explain how to use Files Held Within the Scipts folder

## Folder Structure
* Engine
  * Docker
  * Samba
  * Logs
  * Settings // Possibly
  * Configs // Possibly

